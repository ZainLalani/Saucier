export const RecipeModal = ({ recipe }) => {
    return (
        <div>
            <p>WIP: Full Recipe View Here</p>
        </div>
    );
};
