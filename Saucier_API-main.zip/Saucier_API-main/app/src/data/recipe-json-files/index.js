import file0 from './Apple Fritter Pancakes.json';
import file1 from './Beer Glazed Brats and Sauerkraut.json';
import file2 from './Best Chicken Salad.json';
import file3 from './Black Bean and Corn Salad.json';
import file4 from './Breakfast Pork Cutlets.json';
import file5 from './Buttermilk Pancakes.json';
import file6 from './Cajun Shrimp Stir-Fry.json';
import file7 from './Chicken Katsu.json';
import file9 from './Chilaquiles with Homemade Tomato Sauce.json';
import file10 from './Chinese Eggplant with Garlic Sauce.json';
import file11 from './Chocolate Cereal Breakfast Bars.json';
import file12 from './Classic Macaroni Salad.json';
import file13 from './Easy Fried Rice.json';
import file14 from './Glazed Baked Ham.json';
import file15 from './Golden Butter Rice.json';
import file16 from './Indian Fish Curry.json';
import file17 from './Mexican Polenta Pizza.json';
import file18 from './Pork Chops Al Pastor.json';
import file19 from './Simple Macaroni and Cheese.json';
import file20 from './Sloppy Joes.json';
import file21 from './Slow Cooker Buffalo Chicken Sandwiches.json';
import file22 from './Southern Baked Beans.json';
import file23 from './Souvlaki.json';
import file24 from './Spinach and Potato Frittata.json';
import file25 from './Strawberry Banana Protein Smoothie.json';
import file26 from './Teriyaki Salmon Bowl.json';
import file27 from './Yakisoba Chicken.json';
let recipes = [
    file0,
    file1,
    file2,
    file3,
    file4,
    file5,
    file6,
    file7,
    file9,
    file10,
    file11,
    file12,
    file13,
    file14,
    file15,
    file16,
    file17,
    file18,
    file19,
    file20,
    file21,
    file22,
    file23,
    file24,
    file25,
    file26,
    file27,
];
export default recipes;
