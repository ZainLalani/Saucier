import React from 'react';
/**
 * 1. Recipe Announcement
 * 2. Setting multiple timers and send notification
 * 3. Voice Command
 */
const CookMode = () => {
    return <div>CookMode</div>;
};

export default CookMode;
