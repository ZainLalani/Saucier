import dummyImage from './chorizo-mozarella-gnocchi-bake-cropped-9ab73a3.jpg';
import dummyImage2 from './istockphoto-1457889029-612x612.jpg';

export const dummyRecipe1 = {
    name: 'dum',
    ingredient: ['dum1', 'dum2', 'dum3'],
    cooktime: '1hr 20min',
    image: dummyImage,
};

export const dummyRecipe2 = {
    name: 'dum2',
    ingredient: ['dum1', 'dum2', 'dum3'],
    cooktime: '45min',
    image: dummyImage2,
};
