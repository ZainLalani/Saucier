module.exports = {
    braketSpacing: true,
    jsxBracketSameLine: true,
    singleQuote: true,
    trailingComma: 'all',
    endOfLine: 'auto',
    tabWidth: 4,
};